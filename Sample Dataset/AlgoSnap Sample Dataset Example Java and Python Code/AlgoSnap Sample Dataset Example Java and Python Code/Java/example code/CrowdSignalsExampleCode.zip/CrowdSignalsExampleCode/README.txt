This software is provided by AlgoSnap Inc. under the MIT License

This is example Java code that shows how to read an Avro file, read its schema,
and process Avro record attributes - in this case, magnitude is computed for accelerometer (x,y,z).

You can read more on Apache Avro here: https://avro.apache.org/docs/current/gettingstartedjava.html

All the best and please contact us at info@algosnap.com for any algorithm development or data collection needs!